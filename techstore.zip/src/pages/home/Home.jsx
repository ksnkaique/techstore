import React from 'react'

const Home = () => <h1>Home</h1>

export default Home
