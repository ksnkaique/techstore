const server = require('./server')

module.exports = () => {
    server()
}